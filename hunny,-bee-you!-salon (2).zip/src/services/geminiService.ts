export const generateEmailDraft = async (clientName: string, date: string, service: string) => {
  // Template-based email generation
  return `Subject: Appointment Confirmation - Hunny, bee you! Studio

Hi ${clientName},

We're so excited to see you for your ${service} appointment on ${date}! 

At Hunny, bee you! Studio, we're all about self-expression and expert craft, and we can't wait to help you achieve your perfect look.

Details:
Service: ${service}
Date: ${date}
Location: 1627 West Park Ave. Taylorville, IL. 62568

If you need to reschedule or have any questions, feel free to call us at (217) 820-0675.

See you soon!

Warmly,
Alexis Tucker
Hunny, bee you! Studio`;
};

export const generateServiceDescription = async (serviceName: string) => {
  // Catchy template-based descriptions
  const templates = [
    `Express your true self with our signature ${serviceName}. Expertly crafted just for you.`,
    `Get the look you've always wanted with our professional ${serviceName} service.`,
    `Unleash your inner beauty with a custom ${serviceName} at Hunny, bee you! Studio.`,
    `Precision, artistry, and a style that's unmistakably you. That's our ${serviceName}.`
  ];
  
  return templates[Math.floor(Math.random() * templates.length)];
};
